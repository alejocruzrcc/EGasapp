﻿namespace EGasapp
{
    public class TSender
    {
    }
}