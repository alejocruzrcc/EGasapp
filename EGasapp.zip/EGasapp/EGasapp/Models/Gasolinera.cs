﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EGasapp.Models
{
    public class Gasolinera
    {
        
        //public string Nombre { get; set; }
        //public string Direccion { get; set; }
        //public string Empresa { get; set; }
        //public string Imagen { get; set; }
        //public float Preciocte { get; set; }
        //public float Precioex { get; set; }
        //public float Preciodis { get; set; }

        string nombre;
        string direccion;
        string ciudad;
        string empresa;
        string imagen;
        string preciocte;
        string precioex;
        string preciodis;

        public string Direccion { get {
                return direccion;
            } set{
                direccion = value;

            } }
        public string Nombre{ get {
                return nombre;
            } set {
                nombre = value;
            } }

        public string Ciudad { get {
                return ciudad;
            } set {
                ciudad = value;
            } }
        public string Imagen{ get {
                return imagen;
            } set {
                imagen = value;
            } }
         public string Empresa { get {
                return empresa;
            } set {
                empresa = value;
            } }
         public string Preciocte { get {
                return preciocte;
            } set {
                preciocte = value;
            } }
         public string Precioex { get {
                return precioex;
            } set {
                precioex = value;
            } }
         public string Preciodis { get {
                return preciodis;
            } set {
                preciodis = value;
            } }

    }
}
