﻿using EGasapp.Models;
using GalaSoft.MvvmLight.Messaging;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Geolocation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage.Streams;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Maps;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace EGasapp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MapPage : Page
    {
        public MapPage()
        {
            this.InitializeComponent();

            Messenger.Default.Register<Geopoint>(this, Constants.SetMapViewToken, SetMapView);
            


        }

        
        private async void SetMapView(Geopoint point)
        {
            MyLocationPushpin.Visibility = Visibility.Visible;
            await MainMap.TrySetViewAsync(point, 15, 0, 0, Windows.UI.Xaml.Controls.Maps.MapAnimationKind.Bow);

            
            // Specify a known location.
            BasicGeoposition snPosition1 = new BasicGeoposition() { Latitude = 2.445820695065124, Longitude = -76.59829710373538 };
            BasicGeoposition snPosition2 = new BasicGeoposition() { Latitude = 2.454942586046079, Longitude = -76.58327673325198 };
            BasicGeoposition snPosition3 = new BasicGeoposition() { Latitude = 2.4562235046546177, Longitude = -76.59071181664126 };
            Geopoint snPoint1 = new Geopoint(snPosition1);
            Geopoint snPoint2 = new Geopoint(snPosition2);
            Geopoint snPoint3 = new Geopoint(snPosition3);
            // Create a MapIcon
            MapIcon mapIcon1 = new MapIcon();
            MapIcon mapIcon2 = new MapIcon();
            MapIcon mapIcon3 = new MapIcon();
            mapIcon1.Location = snPoint1;
            mapIcon2.Location = snPoint2;
            mapIcon3.Location = snPoint3;
            mapIcon1.NormalizedAnchorPoint = new Point(0.5, 1.0);
            mapIcon2.NormalizedAnchorPoint = new Point(0.5, 1.0);
            mapIcon3.NormalizedAnchorPoint = new Point(0.5, 1.0);
            //mapIcon1.Image = RandomAccessStreamReference.CreateFromUri(new Uri("ms-appx:///Assets/gas.png"));
            mapIcon1.Title = "Esso";
            mapIcon2.Title = "Terpel";
            mapIcon3.Title = "Esso";
            mapIcon1.ZIndex = 0;
            mapIcon2.ZIndex = 0;
            mapIcon3.ZIndex = 0;



            // Add the MapIcon to the map.
            MainMap.MapElements.Add(mapIcon1);
            MainMap.MapElements.Add(mapIcon2);
            MainMap.MapElements.Add(mapIcon3);

            // Center the map over the POI.
            MainMap.Center = snPoint1;
            
            MainMap.ZoomLevel = 14;

            
    }
        
        private void MapControl_MapElementClick(MapControl sender, MapElementClickEventArgs args)
        {
            InfoGrid.Visibility = Visibility.Visible;
            OverlayGrid.Visibility = Visibility.Visible;
        }
        private void OverlayGrid_Tapped(object sender, TappedRoutedEventArgs e)
        {
            InfoGrid.Visibility = Visibility.Collapsed;
            OverlayGrid.Visibility = Visibility.Collapsed;
        }


    }
}
