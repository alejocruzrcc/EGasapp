﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Data.Json;
using Windows.Storage;

namespace EGasapp.Net
{
   public class preciosapi
    {

        const string URL_PRECIO = "http://localhost:8080/Combustible/public/index.php/precios";
        const string URL_ID1 = "http://localhost:8080/Combustible/public/index.php/precios/1";


        HttpConnection con;

        public preciosapi() { 
            con = new HttpConnection();
        }


        public async Task<bool> precios(string cor, string ext, string dis)
        {
            JsonObject request = new JsonObject();
            request.Add("corriente", JsonValue.CreateStringValue(cor));
            request.Add("extra", JsonValue.CreateStringValue(ext));
            request.Add("diesel", JsonValue.CreateStringValue(dis));
            

            string rta = await con.requestByJsonPost(URL_PRECIO, request.ToString());

            JsonObject rtaJ = JsonObject.Parse(rta);
            var settings = ApplicationData.Current.LocalSettings;
            if (rtaJ["status"].GetString() == "ok")
            {
                string token = rtaJ["token"].GetString();

                settings.Values["token"] = token;
                settings.Values["logged"] = true;

                return true;
            }
            else {
                settings.Values["logged"] = false;
                return false;
            }

        }

    }
}
