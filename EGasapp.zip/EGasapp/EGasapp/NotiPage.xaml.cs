﻿using System;
using EGasapp.Net;
using EGasapp.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace EGasapp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class NotiPage : Page
    {
       

        

        public NotiPage()
        {
            this.InitializeComponent();
            SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility = AppViewBackButtonVisibility.Visible;
            SystemNavigationManager.GetForCurrentView().BackRequested += NotiPage_BackRequested;
        }

        private void NotiPage_BackRequested(object sender, BackRequestedEventArgs e)
        {
            Frame root = Window.Current.Content as Frame;
            if (root.CanGoBack && e.Handled == false)
            {
                root.GoBack();
            }
        }

        private async void notifica(object sender, RoutedEventArgs e)
        {
            preciosapi api = new preciosapi();
            bool success = await api.precios(cor.Text, ext.Text, dis.Text);

            if (success)
            {
                
             }
            else {             
            }

        }
    }
}
