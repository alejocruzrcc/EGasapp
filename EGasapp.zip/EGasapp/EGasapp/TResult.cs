﻿namespace EGasapp
{
    public class TResult
    {
    }
}