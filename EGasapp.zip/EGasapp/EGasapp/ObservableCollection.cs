﻿namespace EGasapp
{
    public class ObservableCollection<T1, T2>
    {
    }
}