﻿using GalaSoft.MvvmLight.Messaging;
using EGasapp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Geolocation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace EGasapp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Menu : Page
    {
        public Menu()
        {
            this.InitializeComponent();
            this.NavigationCacheMode = NavigationCacheMode.Enabled;
            SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility = AppViewBackButtonVisibility.Visible;

        }


        private ObservableCollection<MenuItem> menu;
        public ObservableCollection<MenuItem> MenuList
        {
            get
            {
                if (menu == null)
                {
                    menu = new ObservableCollection<MenuItem>();
                    MenuItem opc1 = new MenuItem() { Icon = "People", Label = "Inicio" };
                    MenuItem opc2 = new MenuItem() { Icon = "Map", Label = "Mapa" };
                    MenuItem opc3 = new MenuItem() { Icon = "Message", Label = "Notificar Precio" };
                    MenuItem opc4 = new MenuItem() { Icon = "AllAPps", Label = "Lista de Estaciones" };
                    MenuItem opc5 = new MenuItem() { Icon = "Target", Label = "Acerca de Gasapp" };

                    menu.Add(opc1);
                    menu.Add(opc2);
                    menu.Add(opc3);
                    menu.Add(opc4);
                    menu.Add(opc5);
                }
                return menu;
            }
            set { menu = value; }
        }

        private void expandir(object sender, RoutedEventArgs e)
        {
            split.IsPaneOpen = !split.IsPaneOpen;
        }

        private void seleccionar(object sender, SelectionChangedEventArgs e)
        {
            switch (List.SelectedIndex)
            {
                case 0:

                    principal.Navigate(typeof(PortadaPage));
                    break;
                case 1:
                    Frame root1 = Window.Current.Content as Frame;
                    root1.Navigate(typeof(MapPage));
                    break;

                case 2:

                    principal.Navigate(typeof(NotiPage));
                    break;
                case 3:

                    principal.Navigate(typeof(ListaEstaciones));
                    break;
                case 4:

                    principal.Navigate(typeof(InfoPage));
                    break;

            }



        }
    }
}
