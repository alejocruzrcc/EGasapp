﻿using EGasapp.Models;
using EGasapp.Net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Data.Json;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace EGasapp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ListaPage : Page
    {
        public ListaPage()
        {
            this.InitializeComponent();

            con = new HttpConnection();

            url = "http://localhost:8080/Combustible/public/index.php/precios";
            
            // this.NavigationCacheMode = NavigationCacheMode.Enabled;
            SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility = AppViewBackButtonVisibility.Visible;
            SystemNavigationManager.GetForCurrentView().BackRequested += ListaPage_BackRequested;
            this.Loaded += ListaPage_Loaded;
        }

        private void ListaPage_Loaded(object sender, RoutedEventArgs e)
        {
            LoadPrecios();
        }

        private HttpConnection con;
        private string url;
        private void ListaPage_BackRequested(object sender, BackRequestedEventArgs e)
        {
            Frame root = Window.Current.Content as Frame;
            if (root.CanGoBack && e.Handled == false)
            {
                root.GoBack();
            }
        }

        public Gasolinera Gasolinera { get; set; }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            Gasolinera g = e.Parameter as Gasolinera;
            Gasolinera = g;

        }

       
        List<Gasolinera> precios;

        int tamano_array;
        public async void LoadPrecios()
        {


            string rta = await con.requestByGet(url);
            JsonArray array = JsonArray.Parse(rta);
            tamano_array = array.Count;
            precios = new List<Gasolinera>();

            
            for (uint i=0; i<tamano_array; i++)
            {

                JsonObject json = array.GetObjectAt(i);



                string cor = json["corriente"].GetString();
                string ext = json["extra"].GetString();
                string die = json["diesel"].GetString();

                
                Tcorriente.Text = cor;
                Textra.Text = ext;
                Tdiesel.Text = die;

                Gasolinera ga = new Gasolinera() { Preciocte = Tcorriente.Text, Precioex = Textra.Text, Preciodis = Tdiesel.Text };


                precios.Add(ga);
            }
            

           
                

            


            
        }

    }
}

