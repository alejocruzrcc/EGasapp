﻿using EGasapp.Net;
using EGasapp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Data.Json;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace EGasapp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ListaEstaciones : Page
    {
        public ListaEstaciones()
        {
            this.InitializeComponent();
            
           
            
            //this.NavigationCacheMode = NavigationCacheMode.Enabled;
            SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility = AppViewBackButtonVisibility.Visible;

        }


        private ObservableCollection<Gasolinera> data;
       

        public ObservableCollection<Gasolinera> Data
        {
            get
            {
                if (data == null)
                {
                    data = new ObservableCollection<Gasolinera>();
                    Gasolinera es1 = new Gasolinera()
                    {
                        Nombre = "Esso Bellavista",
                        Direccion = "CR 9N No 57N-124",
                        Empresa = "Mobil",
                        Imagen = "http://www.baraderoteinforma.com.ar/wp-content/uploads/2014/11/esso.jpg",
                        Preciocte = "8400",
                        Preciodis = "6500",
                        Precioex = "9000",
                    };
                    Gasolinera es2 = new Gasolinera()
                    {
                        Nombre = "La virgen",
                        Direccion = "CR 6A No 24-75",
                        Empresa = "Esso",
                        Imagen = "http://www.estacionesessoymobil.com.co/images/esso-station.jpg",
                        Preciocte = "2030",
                        Preciodis = "2030",
                        Precioex = "7500",
                    };
                    Gasolinera es3 = new Gasolinera()
                    {
                        Nombre = "Terpel Bolivar",
                        Direccion = "CL 10 No 6-45",
                        Empresa = "Terpel",
                        Imagen = "http://www.aditivospetrolabs.com/uploads/images/estacion-de-servicio-mapa.jpg",
                        Preciocte = "8500",
                        Preciodis = "5000",
                        Precioex = "7000",
                    };

                    data.Add(es1);
                    data.Add(es2);
                    data.Add(es3);

                }


                return data;
            }
            set { data = value; }
        }

        private void Seleccion(object sender, SelectionChangedEventArgs e)
        {
            Frame root = Window.Current.Content as Frame;
            Gasolinera g = data.ElementAt(list.SelectedIndex);
            root.Navigate(typeof(ListaPage), g);
        }


        
    }
}
